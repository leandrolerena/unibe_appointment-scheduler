---
title: Geometric Problems
---

<style>
.container{
  display: flex;
}
.col {
  flex: 1;
  margin: 0 0 0 1em;
}
.red {
    color: red;
}
.blue {
    color: blue;
}
.annot {
    color:red;
    visibility: collapse;
}
.optidef {
    color: blue;
    padding: 5px;
    border: 2px;
    border-style: solid;
}

.subproblem {
    color: teal;
}

</style>

# Geometric Problems: Agenda

- Centering
- Classification
- Placement and Location
- Floor planning
- Optional: Minimax delay placement

------------



# Centering

::: {.container}
:::: {.col}

$C \subseteq \mathbb{R}^n$, **bounded** and have **nonempty** interior.

If $x \in C$, then

\
$depth(x, C) = dist(x, \mathbb{R}^n \setminus C)$

::::
:::: {.col}

<!-- ![](2023-04-18-20-19-41.png) -->


::::
:::

::: {.annot}

Largest (euclidean) ball

:::



----------

# Centering

::: {.container}
:::: {.col}

Aside of the geometric interpretation, Centering is also used in

::::: incremental

- **Robustness analysis/Control Theory**: Tolerated perturbation of a system (Example: Drone)
- many more

:::::

::::

:::: {.col}
![](2023-05-03-19-37-46.png)

::::
:::::


------------

# Centering: Chebyshev Center

::: {.container}
:::: {.col}

::::: incremental

$x_{cheb}(C) = \text{arg max}_x\text{ depth}(x, C)$

$\quad\quad\quad \text{  } = \text{arg max}_x\text{ dist}(x, \mathbb{R}^n \setminus C)$

- Point farthest from exterior
- Center of largest ball contained in $C$
- Distance Euclidean $\rightarrow$ ball Euclidean



:::::: fragment

If $C$ is convex, then depth is concave for $x \in C$. So finding the Chebyshev Center is a convex optimization problem.

::::::

:::::

::::

:::: {.col .fragment}

![](2023-04-18-20-19-41.png)


::::

:::

::: {.annot}
Depth concave: Show by forming a line with 2 points in set
:::


----------

#  Centering: Chebyshev Center (of Convex Set)


::: {.container}
:::: {.col}
**Resulting optimization problem**

::::: {.optidef}

$\text{max}_x\quad R$

$\text{s.t}\quad\quad g_i(x, R) \leq 0 \quad i=1,...,m$


:::::

::::: fragment
\
$\text{with}\quad\quad g_i(x, R) = sup_{||u||<=1} f_i(x+Ru)$ 

:::::

\

::::: fragment
**Optimization subproblem(s)**:
:::::
::::: {.optidef .subproblem .fragment}


$\text{max}_u\quad f_i(x + Ru)$

$\text{s.t}\quad\quad u^Tu \leq 1$

:::::

::::: {.annot}
// Ball with Radius R
:::::



::::

:::: {.col}

::::: incremental

- Hard problem; Solvable in practice only if $g_i$ is easy to evaluate
- $g_i$ convex $\rightarrow$ convex optimization problem
- Look at affine constraints ($f_i$ affine)

:::::


::::: {.annot}
Rewrite sup constraint
interpretation: draw ball with an inequality constraint. Can at most touch the constraint! no intersection!
\
blue is convex maximization problem
:::::

::::
:::




---------

#  Centering: Chebyshev Center (of Polyhedron)

::: {.container}
:::: {.col}

If $C$ is a polyhedron, then the constraints $f_i$ can be formulated as linear inequalities.

::::: fragment

$f_i(x) = a_i^Tx \leq b_i \quad i = 1,...,m$

:::::
::::: fragment

\

Then 

$g_i(x, R) = sup_{||u|| \leq 1} a_i^T(x+Ru) -b_i$

:::::
::::: fragment

$\quad\quad\quad= a_i^Tx + R ||a_i||_* - b_i$

\

:::::
::::: fragment

$||a_i||_*$ is called the **dual norm**. Chebyshev center can be found by solving the LP: 

:::::

::::
:::: {.col}

::::: fragment

**Convex optimization problem**:

:::::: {.optidef}

$\text{max}_{x, R}\quad R$

$\text{s.t.}\quad a_i^Tx + R||a_i||_* \leq b_i \quad i = 1,...,m$

::::::

:::::

::::: {.annot}
Why is $||a_i||_*$ easy to evaluate? LP has variables x and R, so precomputed.

If euclidean norm, the dual is also the euclidean norm (show this!)

Gauchy Schwarz 

$|\langle u , v \rangle|^2 \leq \langle u , u \rangle * \langle v , v \rangle$

$||u||_2 := \langle u , u \rangle^{1/2}$
:::::

::::
:::

---------

# Centering: Analytic center

::: {.container}

:::: {.col}

Here, we look at a set of convex inequalities and linear equalities and find an analytic center $x_{ac}$ by formulating a **logarithmic barrier** for the inequalities.

::::: {.optidef}

$\text{min}_x \quad -\sum_{i=1}^{m} log(-f_i(x))$

$\text{s.t.} \quad\quad Fx = g$

::::: 


::::: {.annot}

- Strict inequality system ($f_i(x) \lt 0$ is feasible)
- Keep in mind that $f_i$ may be non-linear!

Show what happens if not strictly feasible (log-barrier)

:::::


::::

:::: {.col}


<!-- $C = \{x \quad | \quad f_i(x) \lt 0, i=1,...,m, \quad Fx = g\}$ is **bounded** and **non-empty**. -->

Example: **Quarter Circle**

![Normal rectangle](assets/plots/analytic-center-circle.html){ width=500px height=400px .print }

::::

:::






---------

# Centering: Analytic center


::: {.container}

:::: {.col}

**4 inequalities for rectangle ($C$)**

![Normal rectangle](assets/plots/analytic-center.html){ width=500px height=500px .print }
::::

:::: {.col}
**6 inequalities for rectangle ($C'$)**
![-x <= 0 (3 times)](assets/plots/analytic-center-repeated.html){ width=500px height=500px .print }
::::

:::

---------


# Centering: Analytic center

::: {.container}

:::: {.col}
::::: incremental
- $C$ and $C'$ may represent the same set but have a different analytic center.
- **Analytic center of a set of equalities and inequalities**, not analytic center of a set of points.
:::::
::::

:::: {.col}
![](2023-04-18-22-09-31.png)
::::

:::

---------

# Analytic center of linear inequalities


::: {.container}

:::: {.col}
::::: incremental

- Analytic center is the point that maximizes the product of distances to the defining hyperplanes ($f_i$ linear).
- Can derive an inner and outer ellipsoid based on the Hessian of the logarithmic barrier.
- Weaker result than other methods, but may be more efficiently computable.
:::::
::::: {.annot}
show inner ellipsoid, outer ellipsoid
:::::

::::

:::: {.col}
![](2023-04-18-22-09-31.png)
::::

:::


----------

# Classification: Goal

::: {.container}
:::: {.col}

We look at two sets of Datapoints

- $\mathcal{X} = \{x_1, x_2, ... ,x_N\}$
- $\mathcal{Y} = \{y_1, y_2, ... ,y_M\}$

Seek for a function $f: \mathbb{R}^n \rightarrow \mathbb{R}$ which satisfies:

::::: incremental

- $f(x_i) > 0, \quad i = 1, ... , N$
- $f(y_i) < 0, \quad i = 1, ... , M$

- Strict inequality leads to a **strong separation** (perfect classifier)
:::::

::::
:::: {.col}
![](points-only.png)
::::
:::

# Linear discrimination

::: {.container}
:::: {.col}

In Linear discrimination, we seek an **affine function** which separates $\mathcal{X}$ and $\mathcal{Y}$

::::: fragment

A function of the form $f(x) = a^Tx-b$, such that:

:::::

::::: incremental

- $a^Tx_i-b > 0, \quad i = 1, ... , N$
- $a^Ty_i-b < 0, \quad i = 1, ... , M$

- Also called a **separating Hyperplane**

:::::

::::
:::: {.col}
![](2023-04-20-20-55-31.png)
::::
:::

----------

# Linear discrimination

::: {.container}
:::: {.col}

We can scale the function $f(x) = a^Tx-b$, such that:

- $a^Tx_i-b \geq 1, \quad i = 1, ... , N$
- $a^Ty_i-b \leq -1, \quad i = 1, ... , M$

\

Will use this version in upcoming slides!

:::: {.annot}
what could be a robust classifier?

draw some lines
::::

::::
:::: {.col}
![](2023-04-20-20-55-31.png)
::::
:::

----------

# Robust linear discrimination

::: {.container}
:::: {.col}

Introduce notion of **robustness**: Maximize the gap between hyperplane and $\mathcal{X}$, $\mathcal{Y}$ respectively

:::: {.optidef .fragment}

$\text{max}\quad t$

$\text{s.t.}\quad a^Tx_i -b \geq t \quad i=1,...,N$

$\quad\quad a^Ty_i -b \leq -t \quad i=1,...,M$

$\quad\quad ||a||_2 \leq 1$
::::

\

:::: incremental
- t positive $\iff$ data is linearly separable
::::

:::: {.annot}
- t half of the distance of both sets
::::

::::
:::: {.col}
![](2023-04-20-21-52-22.png)
::::
:::

----------

# Robust linear discrimination: Dual

 
::: {.container}
:::: {.col}

**Primal Problem**

:::: {.optidef}

$\text{max}\quad t$

$\text{s.t.}\quad a^Tx_i -b \geq t \quad i=1,...,N$

$\quad\quad a^Ty_i -b \leq -t \quad i=1,...,M$

$\quad\quad ||a||_2 \leq 1$
::::

:::: {.annot}

\ 

- KKT Conditions
::::

::::
:::: {.col}

::::: fragment

**Lagrangian**

$L(a,b,u,v,\lambda) = -t $

$\quad\quad\quad\quad\quad\quad + \sum_{i=1}^{N}u_i(t+b-a^Tx_i)$

$\quad\quad\quad\quad\quad\quad + \sum_{i=1}^{M}v_i(t-b+a^Ty_i)$

$\quad\quad\quad\quad\quad\quad + \lambda(||a||_2-1)$


**Dual constraints**

:::::

::::
:::


----------

# Robust linear discrimination: Dual

::: {.container}

:::: {.col}

**Lagrangian**

$L(a,b,u,v,\lambda) = -t $

$\quad\quad\quad\quad\quad\quad + \sum_{i=1}^{N}u_i(t+b-a^Tx_i)$

$\quad\quad\quad\quad\quad\quad + \sum_{i=1}^{M}v_i(t-b+a^Ty_i)$

$\quad\quad\quad\quad\quad\quad + \lambda(||a||_2-1)$


**Dual constraints**

1. $\sum_{i=1}^{M}v_i = \sum_{i=1}^{N}u_i = 1/2$
2. $u \succeq 0$, $v \succeq 0$, $\lambda \geq 0$

::::

:::: {.col}

**Dual function**

$g(u,v,\lambda) = \text{inf}_{a,b}(L(a,b,u,v,\lambda))$


::::

:::

----------

# Robust linear discrimination: Dual

::: {.container}

:::: {.col}

**Dual function**

$g(u,v,\lambda) = \text{inf}_{a,b}(L(a,b,u,v,\lambda))$

$= \text{inf}_{a}(a^T(\sum_{i=1}^{M}v_iy_i  - \sum_{i=1}^{N}u_ix_i) + \lambda||a||_2 - \lambda)$

$= \left\{\begin{array}{lr}
        -\lambda,   & ||\sum_{i=1}^{M}v_iy_i  - \sum_{i=1}^{N}u_ix_i||_2 \leq \lambda\\
        -\infty, & \text{else }\\
        \end{array}\right.$

::::: {.annot}

if (..) bigger than $\lambda$ or -(..) bigger than $\lambda$ (inverse a)

:::::

::::

:::: {.col}

**Dual problem**


::::

:::

----------

# Robust linear discrimination: Dual

::: {.container}

:::: {.col}

**Dual problem**

::::: {.optidef}

$\text{max } -||\sum_{i=1}^{M}v_iy_i  - \sum_{i=1}^{N}u_ix_i||_2$

$\text{s.t}\quad \sum_{i=1}^{M}v_i = \sum_{i=1}^{N}u_i = 1/2$

$\quad\quad u \succeq 0$

$\quad\quad v \succeq 0$


:::::

::::: {.annot}

interpretation (point convex hull)

support vectors

complementary slackness

:::::

::::

:::: {.col}

![](2023-04-20-21-52-22.png)

::::

:::

----------

# Support Vector Classifier


::: {.container}

:::: {.col}

Handle the case when sets are **not linearly separable**

\

:::: {.optidef}

$\text{min}\quad 1^Tu + 1^Tv$

$\text{s.t.}\quad a^Tx_i -b \geq 1 - u_i \quad i=1,...,N$

$\quad\quad a^Ty_i -b \leq -(1 - v_i) \quad i=1,...,M$

$\quad\quad u \succeq 0$, $v \succeq 0$

::::

:::: {.annot}
recover original constraints on $v = u = 0$

draw some points which violate

l1-norm (few violations, but may be big)
::::

::::

:::: {.col}

![](2023-04-20-21-52-22.png)


::::

:::

----------

# Support Vector Classifier



::: {.container}

:::: {.col}

Support Vector Classifier with **regularization**

$\gamma$: Tradeoff between **robustness** and **classification error**

\

:::: {.optidef}

$\text{min}\quad ||a||_2 + \gamma(1^Tu + 1^Tv)$

$\text{s.t.}\quad a^Tx_i -b \geq 1 - u_i \quad i=1,...,N$

$\quad\quad a^Ty_i -b \leq -(1 - v_i) \quad i=1,...,M$

$\quad\quad u \succeq 0$, $v \succeq 0$

::::

:::: {.annot}

\

regularization

$slab = 1/||a||_2$

::::

::::

:::: {.col}

\


SVM [Demo](https://greitemann.dev/svm-demo)


::::

:::


------------

# Placement and location

::: {.container}

:::: {.col .incremental}

Look at **points** connected by **links**


- Some points max be fixed, some are to place (optimally)
  - Usually a measure of total interconnection length is minmimized
  - "Transport Cost"

::::: fragment
$\sum_{(i,j) \in \mathcal{A}} f_{ij}(x_i,x_j)$ - cost function (convex)
:::::
- $\mathcal{A}$ - set of arcs (ordered)
- $f_{ij}$ convex functions

::::

:::: {.col}

![](manhattan.png)

<p class="annot"> Add graph for illustration</p>

::::
:::


----------

# Linear facility location problem

::: {.container}
:::: {.col}
$\text{cost} = \sum_{(i,j) \in \mathcal{A}} ||x_i - x_j ||_1$

::::: fragment

Can also add (nonnegative) weight

$\text{cost}_{\text{weighted}} = \sum_{(i,j) \in \mathcal{A}} w_{ij}||x_i - x_j ||_1$

:::::

::::: incremental

- For a logistic problem, this is called **Manhattan routing**
:::::

::::

:::: {.col}
![](manhattan.png)
::::
:::

------------

# Facility location problem: One free point

If the location of one facility has yet to be determined, we may want to find the optimal position **(u, v)**, which minimizes the total cost.

::: {.container}
:::: {.col .fragment}
**$l_1-norm$**

---

$\text{min}_x\quad\sum_{i=1}^{K} ||x - x_i ||_1$

$\text{min}_{u,v}\quad\sum_{i=1}^{K}(|u - u_i| + |v - v_i|)$


- **Median** of the points 

(if K is even, can be a rectangle of optimal points)
::::

:::: {.col .fragment}
**$l_2-norm$**

---

$\text{min}_x\quad\sum_{i=1}^{K} ||x - x_i ||_2$

$\text{min}_{u,v}\quad\sum_{i=1}^{K} ((u - u_i)^2 + (v - v_i)^2)^{1/2}$

- **Weber point**


::::
:::


# Linear facility location problem: Placement constraints (1)

We can impose constraints on the positions $(x_1,...,x_p)$ we want to find.

::: {.container}
:::: {.col .incremental}

Constraints **preserving convexity**:

- Position within line, segment, ellipsoid, square
- Relative positioning (max distance)


::::: {.annot}

why preserve convexity?

:::::

::::
:::: {.col}
![](manhattan.png)
::::
:::

-----------

# Linear facility location problem: Placement constraints (2)

We can impose constraints on the positions $(x_1,...,x_p)$ we want to find.

::: {.container}
:::: {.col .incremental}

Constraints **preserving convexity**:

- Relative position constraints ($x_1$ left of $x_2$)
- Bounding Box of a group of points

::::: {.fragment .optidef}

$\text{min}\quad \text{cost}$

$\text{s.t}\quad 2*1^T(v-u)\leq P_{max}$

$\quad\quad u \preceq x_i \preceq v \quad i = 1,..,p$



:::::

::::
:::: {.col}
![](manhattan.png)
::::
:::

-----------

# Nonlinear facility location problem

We can apply $h(z)$ to our cost function; $h(f(x))$ needs to be a convex function to be tractable

::: {.annot}
Proof, second derivative with chain rule

$h(f(x))'' = h''(f(x))*f'(x)^2 + h'(f(x))*f''(x)$

sum of convex, multiplication with positive scalar preserve convexity

:::

----------

# Nonlinear facility location problem

$\sum_{(i,j) \in \mathcal{A}} w_{ij}h(||x_i - x_j ||_2)$ is convex if h is a **convex** and **monotonically increasing function**

\

::: incremental

- For $h(z) = z^2$ the facility location problem is called a **quadratic placement problem**
- With total cost: $\sum_{(i,j) \in \mathcal{A}} w_{ij}||x_i - x_j ||_2^2$

\

- **One free point**: Average of the fixed points.

:::

::: {.annot}

$x^2$ not increasing (but on positive numbers, it is)

Show derivation for average

:::

----------

# Placement of free points


::: {.container}
:::: {.col}



for $h$ being a **deadzone** function

  $h(z) = \left\{\begin{array}{lr}
        0,   & \text{for } |z| \leq \gamma\\
        |z| -\gamma, & \text{for } |z| \geq \gamma\\
        \end{array}\right.$



\


for $h$ being a **quadratic linear** function

  $h(z) = \left\{\begin{array}{lr}
        z^2,   & \text{for } |z| \leq \gamma\\
        2\gamma|z| - \gamma^2, & \text{for } |z| \geq \gamma\\
        \end{array}\right.$





::::
:::: {.col}

![Comparison of Penalties](assets/geogebra/deadzone-quadraticlinear-slider.ggb){ width=600 height=500px app-width=1200 app-height=700 } 


:::: {.annot}
How does it look? consequences?

A lot of the distances will be of length $\gamma$
::::

\ 

:::: {.annot}
How does it look? consequences?

Some distances big, a lot very small.

::::

::::
:::


<!-- #  Visualization of Deadzone and Quadratic-Linear

![Comparison of Penalties](assets/geogebra/deadzone-quadraticlinear-slider.ggb){ width=1000px height=500px app-width=1500 app-height=700 } 



---------- -->


# Floor Planning



::: {.container}

:::: {.col .incremental}

- Extension of Placement
- **Boxes** (rectangles) **instead of points**
- Boxes **must not overlap**

::::: {.annot}

also here, may want to minimize perimeter

distance constraints

min distance

ordered x's

:::::

::::

:::: {.col}
![](2023-04-23-14-36-28.png){width=400px}
::::

:::

---------


# Flow problem

::: {.container}
:::: {.col .incremental}

Look at a flow problem: **source** and **destination/sink** nodes

- **Source**: Fabrication of a product
- **Sink/Destination**: Retailer
- **Other Nodes**: Intermediate Storage

::::: fragment
Here: **Associate cost with edges**.
:::::

::::
:::: {.col}
![](manhattan.png)
::::
:::

----------

# Path constraints

::: {.container}
:::: {.col}

We can also impose upper bound on the **length of the path**:

::::: incremental

- a **p-link**-path along points $x_1,...,x_N$ is represented by a sequence $i_0, i_1, .., i_p \in \{1,...,N\}$
- the **cost of such path** is $||x_{i_1} - x_{i_0}|| + ||x_{i_2} - x_{i_1}|| + ... + ||x_{i_p} - x_{i_{p-1}}||$
- sum of convex functions **preserves convexity**

:::::

::::
:::: {.col}
![](manhattan.png)
::::
:::

----------

# Minimax delay placement

Look at a flow problem: **source** and **destination/sink** nodes

- Placement of "free nodes" to optimize some kind of flow.

::: fragment
:::: {.optidef}
$\text{min}\quad T_{max} = \text{max} \{ ||x_{i_1} - x_{i_0}|| + ||x_{i_2} - x_{i_1}|| + ... + ||x_{i_p} - x_{i_{p-1}}|| \quad | \quad i_0, i_1, .., i_p \text{ is a source-sink path} \}$
::::
:::
\

::: {.container}
:::: {.col}
::::: incremental
- Convex
- Potentially **exponential number** of paths (in number of nodes and arcs).
- **Reformulate**!
:::::
::::
:::: {.col}
::::: {.annot}
show translation of max
:::::
::::
:::



----------

# Minimax delay placement: Reformulation

Recursive approach (Dynamic Programming).

::: {.container}
:::: {.col}
- $\mathcal{A}$ is ordered
::::
:::: {.col}
- $\tau_k$ denotes the longest path from sink to node k
::::
:::

::: {.annot}
Operations $\approx$ number of links
insert graph
:::

![](assets/dot/network.dot.png){height=400px}


----------

# Minimax delay placement: Reformulation

With this approach, we can reformulate our problem:

::: {.optidef}

$\text{min} \quad \text{max} \{\tau_k \quad | \quad k \text{ a source node} \}$

$\tau_k = 0 \quad k \text{ a sink node}$

$\tau_k = max \{ ||x_j - x_k || + \tau_j \quad | \quad (k,j) \in \mathcal{A}\}$

:::

\

::: incremental

- Not convex!

:::

---------

# Minmax delay placement: Reformulation

Reformulate with upper bounds $T_k \geq \tau_k$

::: {.optidef}

$\text{min} \quad \text{max} \{T_k \quad | \quad k \text{ a source node} \}$

$T_k = 0 \quad k \text{ a sink node}$

$T_k \geq max \{ ||x_j - x_k || + T_j \quad | \quad (k,j)  \in \mathcal{A}\}$

:::

\

::: incremental
- Inequality constraint can be convex
- Convex!
:::

---------

<!-- 
-----------

# hello

asd

![](assets/images/2023-04-14-21-12-11.png)


--------


# Quiz

::: center
Wer bekommt am Ende die Prinzessin?
:::

::: {.quiz .w80}
- [ ] Donkey Kong 
    - Nein, der ist böse!
- [ ] Sponge Bob 
    - Nein, der lebt unter Wasser!
- [ ] Kleine A-Loch 
    - Nein, den mag keiner!
- [X] Supermario
    - Klar!
:::


# Zuordnungsaufgaben

::: quiz-mi
Prinzessin
: ![](data/peach.png){height=100px}

Donkey Kong
: ![](data/donkeykong.png){height=100px}

Supermario
: ![](data/supermario.png){height=100px}
:::


# Zuordnungsaufgaben

::: quiz-mi
Laplace
: $\laplace f$

Gradient
: $\grad f$

Divergenz
: $\grad \cdot f$ 

Quatsch
: $\laplace \cdot f$ 
:::



----------

# Geogebra

![A quadratic function!](assets/geogebra/geogebra-export.ggb){ width=600px height=500px app-width=900 app-height=700 } 

-----------



::: {.container}
:::: {.col}
Column 1 Content
::::
:::: {.col}
Column 2 Content

::::: {.red}
red
:::::

::::
:::





# Contour plot

![Auf `3D Surface` klicken!](assets/plots/log-test.html){ width=1000px height=500px .print }


------------

-->