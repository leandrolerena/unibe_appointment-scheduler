---
title: Appointment Scheduler
---

<style>
.container{
  display: flex;
}
.col {
  flex: 1;
  margin: 0 0 0 1em;
}
.red {
    color: red;
}
.blue {
    color: blue;
}
.annot {
    color:red;
    visibility: collapse;
}
.optidef {
    color: blue;
    padding: 5px;
    border: 2px;
    border-style: solid;
}

.subproblem {
    color: teal;
}
.font-24{
    font-size: 24px
}

.font-22{
    font-size: 22px
}

.font-20{
    font-size: 20px
}

</style>

# Appointment Scheduler 


::: {.container}
:::: {.col}

- Motivation
- Modeling choices and assumptions
- Problem formulation
- Results
- Conclusion and Remarks

::::
:::: {.col}
![](2023-05-24-19-17-59.png)
::::
:::

------------

# Motivation

::: {.container}
:::: {.col .incremental}

At some area:

- Multiple **service providers**
- **User** wants to consume one or more services
- **Unnecessary** waiting times (queueing)

::::
:::: {.col}
![](2023-05-24-19-17-59.png)
::::
:::

------------

# Modelling choices and assumptions


::: {.container}
:::: {.col .incremental}

- Assign **user** to a **time-spot**
- Many users, few providers
- User visits **few (1-3)** providers
- Create only as many spots as needed

::::
:::: {.col}

![](queue.png)

::::
:::

::: {.container}
:::: {.col .fragment .incremental}
**Notation**

- $K$ Service Providers
- $N$ Users
- $N_k$ users requested service $k$


::::
:::: {.col .incremental}

\

- $J_k$ spots for service $k$
- Position $j = 1,...,J_k$ in service $k$
- $J_k = N_k$

::::
:::


------------


# Timeslots for service


::: {.container}
:::: {.col}

**Concept**: Timeslot for Service

**Variable**: $s_{j,k} \in \mathbb{R}$ 

::: {.font-24 .fragment}
($k = 1, ..., K \quad j= 1, ..., J_k$)

$\text{opening}_k$ and $\text{closing}_k$ from problem data
:::

::::
:::: {.col}

![](queue_1_snippet.png)

::::
:::

\

::: {.container}
:::: {.col .fragment .incremental}
**Properties**

- Ordered, No Overlap
- Not before opening hour
- Not after closing hour

::::
:::: {.col .fragment .incremental}
**Constraints** 

- $s_{j,k} + t_k \leq s_{j+1,k}$ 
- $\text{opening}_k \leq s_{1,k}$
- $s_{J_k,k} + t_k \leq \text{closing}_k$


::::
:::


------------

# User to time-spot assignment

::: {.container}
:::: {.col}

**Concept**: Assigning users to spots in service

**Variable**: $x_{ij,k} \in \{0,1\}$ 

::: {.font-24 .fragment}
(for  $k = 1, ..., K \quad j= 1, ..., J_k \quad i= 1, ..., N_k$)
:::


::::
:::: {.col}

![](assignment.png){width=80%}

::::
:::

\

::: {.container}
:::: {.col .fragment .incremental}
**Properties**

- One user per spot
- One spot per user

::::
:::: {.col .fragment .incremental}
**Constraints** 

- $\sum_{i=1}^{N} x_{ij,k} = 1$
- $\sum_{j=1}^{N} x_{ij,k} = 1$

::::
:::

------------

# No Cross-Service overlaps

::: {.container}
:::: {.col}

**Concept**: Spots between queues can not overlap if assigned to the same user

**Variable**: $b_{i,kk'} \in \{0,1\}$ 

::: {.font-20 .fragment}
( $k, k' = 1, ..., K \quad j,j'= 1, ..., J_{k} \quad i= 1, ..., N_k \quad k \neq k'$)
:::

::::
:::: {.col}

![](queue.png){width=80%}


::::
:::

\

::: {.container}
:::: {.col .fragment .incremental}
**Properties**

- Antisymmetry 
- Transitivity
- No cross-overlaps

::::
:::: {.col .fragment .incremental}
**Constraints** 

- $b_{i,kk'} = 1 - b_{i,k'k}$ 
- $b_{i,ab} + b_{i,bc} - 1 <=  b_{i,ac}$
- $s_{j,k} + t_k \leq s_{j',k'} + M * (3 - x_{ij,k} - x_{ij',k'} - b_{i,kk'})$ 

::::
:::

------------

# Cost

::: {.container}
:::: {.col}

**Concept**: Fulfill user preferences as good as possible

**Variable**: $c_{ij,k} \in \mathbb{R}$ 

:::{.font-20 .fragment}
($k = 1, ..., K \quad j= 1, ..., J_{k} \quad i= 1, ..., N_k$)

$e_{i,k}$ and $l_{i,k}$ from problem data
:::

::::
:::: {.col}

![](deadzone.png){width=80%}

::::
:::

\

::: {.container}
:::: {.col .fragment .incremental}
**Properties**

- Positivity
- Penalty for too early
- Penalty for too late

::::
:::: {.col .fragment .incremental}
**Constraints** 

- $c_{ij,k} \geq 0$ 
- $c_{ij,k} \geq e_{i,k} - s_{j,k} - M * (1-x_{ij,k})$
- $c_{ij,k} \geq s_{j,k} + t_k - l_{i,k}  - M * (1-x_{ij,k})$ 

::::
:::

-----------


# Final Problem formulation


$\min_{\boldsymbol{x,s,c,b}} \sum_{k=1}^{K}\sum_{j=1}^{J}\sum_{i=1}^{N} c_{ij,k}$

s.t. 

::: {.container .font-24}
:::: {.col}

::::: fragment

(Timeslots for Service)

- $s_{j,k} + t_k \leq s_{j+1,k}$ 
- $\text{opening}_k \leq s_{1,k}$
- $s_{J_k,k} + t_k \leq \text{closing}_k$

:::::

-------

::::: fragment

(Assignment)

- $\sum_{i=1}^{N} x_{ij,k} = 1$
- $\sum_{j=1}^{N} x_{ij,k} = 1$

:::::

::::
:::: {.col}

::::: fragment

(No Cross-Service overlaps)

- $b_{i,kk'} = 1 - b_{i,k'k}$ 
- $b_{i,ab} + b_{i,bc} - 1 <=  b_{i,ac}$
- $s_{j,k} + t_k \leq s_{j',k'} + M * (3 - x_{ij,k} - x_{ij',k'} - b_{i,kk'})$ 

:::::

-------

::::: fragment


(Cost)

- $c_{ij,k} \geq 0$ 
- $c_{ij,k} \geq e_{i,k} - s_{j,k} - M * (1-x_{ij,k})$
- $c_{ij,k} \geq s_{j,k} + t_k - l_{i,k}  - M * (1-x_{ij,k})$ 

:::::

::::
:::

----------

# Results: Scenario "Random Concentration"


::: {.container}
:::: {.col}

![](./assets/Random_Concentration/queue_perspective.png)

::::
:::: {.col}

![](./assets/Random_Concentration/user_perspective.png)

::::
:::

----------

# Results: Scenario "Random Intervals"


::: {.container}
:::: {.col}


![](./assets/Random_Intervals/queue_perspective.png)

::::
:::: {.col}

![](./assets/Random_Intervals/user_perspective.png)

::::
:::

----------

# Results: Scenario "No Preferences"


::: {.container}
:::: {.col}


![](./assets/No_preferences/queue_perspective.png)

::::
:::: {.col}

![](./assets/No_preferences/user_perspective.png)

::::
:::

----------

# Results: Scenario "Concentrated on 500"


::: {.container}
:::: {.col}


![](./assets/Concentrated_on_500/queue_perspective.png)

::::
:::: {.col}

![](./assets/Concentrated_on_500/user_perspective.png)

::::
:::

---------

# Comparison of results

\


| Scenario             | Total Cost | Time Used     |
|----------------------|------------|---------------|
| Random Concentration | 308.49     | 38.03 s         |
| Random Intervals     | 0.0        | 2.73 s         |
| No Preferences       | 0.0        | 0.8 s          |
| Concentrated on 500  | 921.49     | 9.7 s          |

# Conclusion

::: incremental

**Practicality**

- Very flexible formulation. <span class="annot">Could fix spots, fix assignments, different cost function</span>
- A lot of constraints, need to assume few service providers and few requests per user
- Each additional constraint helps! <span class="annot">(additional user preference: k before k'), priority list</span>

:::: fragment

**Scalability**

::::

- Partitioning and Heuristics <span class="annot">By day, indentify independent service providers</span>
- Improve formulation

:::: fragment

**Personal**

::::

- Intuition

:::

---------

# Remarks

::: incremental 

:::: fragment

**CVXPy**

::::

- **Great Library!!!** <span class="annot">Formulate problem with special variable type, operator overloading</span>
- Cannot set parameters for all optimizers

:::: fragment

**General**

::::

- Sometimes big rounding erros (*math.isclose()* defaults not enough)
- **Gurobi is ~50 times faster** <span class="annot">(makes more use of parallelism)</span>

::: 

----------

# End

Thank you for listening!

---------

<!-- 


::: {.container}
:::: {.col}



::::
:::: {.col}


::::
:::


-----------

# hello

asd

![](assets/images/2023-04-14-21-12-11.png)


--------


# Quiz

::: center
Wer bekommt am Ende die Prinzessin?
:::

::: {.quiz .w80}
- [ ] Donkey Kong 
    - Nein, der ist böse!
- [ ] Sponge Bob 
    - Nein, der lebt unter Wasser!
- [ ] Kleine A-Loch 
    - Nein, den mag keiner!
- [X] Supermario
    - Klar!
:::


# Zuordnungsaufgaben

::: quiz-mi
Prinzessin
: ![](data/peach.png){height=100px}

Donkey Kong
: ![](data/donkeykong.png){height=100px}

Supermario
: ![](data/supermario.png){height=100px}
:::


# Zuordnungsaufgaben

::: quiz-mi
Laplace
: $\laplace f$

Gradient
: $\grad f$

Divergenz
: $\grad \cdot f$ 

Quatsch
: $\laplace \cdot f$ 
:::



----------

# Geogebra

![A quadratic function!](assets/geogebra/geogebra-export.ggb){ width=600px height=500px app-width=900 app-height=700 } 

-----------



::: {.container}
:::: {.col}
Column 1 Content
::::
:::: {.col}
Column 2 Content

::::: {.red}
red
:::::

::::
:::





# Contour plot

![Auf `3D Surface` klicken!](assets/plots/log-test.html){ width=1000px height=500px .print }


------------

-->